import type React from "react"
export default function CacTrangLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <>{children}</>
}
